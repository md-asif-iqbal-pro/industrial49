
def greet():
    print("Hello from Module 1!")
