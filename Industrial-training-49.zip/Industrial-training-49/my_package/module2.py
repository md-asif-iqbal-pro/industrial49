
def farewell():
    print("Goodbye from Module 2!")
